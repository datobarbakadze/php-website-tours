OpenJS-Tags
===========

Simple jQuery Tagging from a single input box. Works really well with OpenJS Autofill